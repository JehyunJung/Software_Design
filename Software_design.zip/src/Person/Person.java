package Person;
//������ package
public class Person{
	String name;
	String number;
	
	public Person(String name, String number){
		this.name=name;
		this.number=number;
	}
}
