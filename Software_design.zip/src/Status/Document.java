package Status;

public class Document{
	String stu_num;			// student ID num
	String stu_name;		// student name
	String coll_name;		// college name
	String doc_type;		// document type
	public Document(String stu_num, String stu_name, String col_name, String doc_type) {
		this.stu_num=stu_num;
		this.stu_name=stu_name;
		this.coll_name=col_name;
		this.doc_type=doc_type;
	}
	
}
